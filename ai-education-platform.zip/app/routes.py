from flask import render_template, request, redirect, url_for, Blueprint
from app import db
from .models import User, Quiz, LearningPath

main = Blueprint('main', __name__)

@main.route('/')
def home():
    return render_template('home.html')

@main.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        user = User(username=username, email=email)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('main.home'))
    return render_template('register.html')

@main.route('/quiz/<int:quiz_id>', methods=['GET', 'POST'])
def quiz(quiz_id):
    quiz = Quiz.query.get_or_404(quiz_id)
    if request.method == 'POST':
        selected_answer = request.form['answer']
        if selected_answer == quiz.correct_answer:
            return render_template('result.html', result="Correct!")
        else:
            return render_template('result.html', result="Incorrect. Try again.")
    return render_template('quiz.html', quiz=quiz)